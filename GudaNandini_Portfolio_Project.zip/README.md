# Guda Nandini - Personal Portfolio Website

## 📌 Overview
This is a responsive **Portfolio Website** built using **HTML, CSS, and JavaScript**.  
It showcases sections like About, Skills, Projects, and Contact.

## 🚀 Features
- Clean, responsive design
- Interactive navigation
- Simple contact form with confirmation message
- Showcases skills & sample projects

## 🛠️ Tech Stack
- HTML5
- CSS3
- JavaScript (Vanilla)

## 📂 How to Run
1. Download/clone this project.
2. Open `index.html` in your browser.
3. Explore the portfolio website!

## ✨ Author
Created by *Guda Nandini*  
📧 Email: gnandinireddy34@gmail.com